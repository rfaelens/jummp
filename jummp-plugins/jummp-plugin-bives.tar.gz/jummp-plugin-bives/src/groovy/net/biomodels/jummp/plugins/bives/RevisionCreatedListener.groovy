package net.biomodels.jummp.plugins.bives

import org.apache.log4j.Logger
import org.springframework.context.ApplicationEvent
import org.springframework.context.ApplicationListener
import net.biomodels.jummp.core.events.RevisionCreatedEvent

/**
 * @short Listener for new revisions
 * 
 * @author Robert Haelke, robert.haelke@googlemail.com
 * @date 20.06.2011
 * @year 2011
 */
class RevisionCreatedListener implements ApplicationListener {
    /**
     * The logger for this class
     */
    Logger log = Logger.getLogger(getClass())

    public void onApplicationEvent(ApplicationEvent event) {
		println("this is an ApplicationEvent")
        if (event instanceof RevisionCreatedEvent) {
			println("soon here be fantastic code... with many cool stuff")
        }
    }
}
